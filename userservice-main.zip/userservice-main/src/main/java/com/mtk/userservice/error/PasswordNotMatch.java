package com.mtk.userservice.error;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "New Password and Confirm Password Does Not Match Credentials")
public class PasswordNotMatch extends Exception {

}
